#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
using vi = vector<ll>;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<vector<int>> start(2 * n);
    for (int i = 0; i < n; ++i) {
        int x;
        cin >> x;
        start[i + x].push_back(i);
    }

    const int inf = 1e9;

    vector<int> dp(2 * n, inf);
    vector<int> window(2 * n);

    deque<int> d;

    dp[0] = 0;
    for (int i = 0; i < 2 * n; ++i) {
        for (auto s : start[i]) dp[i] = min(dp[i], window[s] + i - s);
        while (!d.empty() && dp[d.back()] >= dp[i]) d.pop_back();
        d.push_back(i);
        window[i] = dp[d.front()];
        if (!d.empty() && d.front() == i - k) d.pop_front();
    }

    cout << *min_element(begin(dp) + n - k, end(dp)) << '\n';
    return 0;
}
