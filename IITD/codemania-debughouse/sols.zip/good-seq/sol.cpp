#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
using vi = vector<ll>;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        const int B = 32;
        const int mod = 1e9 + 7;
        int n, m;
        cin >> n >> m;
        vector<vector<vector<int>>> dp(n + 1,
                                       vector<vector<int>>(B, vector<int>(B)));
        for (int i = 0; i < B; ++i)
            for (int j = i + 1; j < B; ++j) dp[1][i][j] = 1;
        for (int i = 2; i <= n; ++i)
            for (int j = 0; j < B; ++j)
                for (int k = j + 1; k < B; ++k)
                    for (int l = max(0, j - m); l < B && l <= j + m; ++l)
                        for (int p = max(l + 1, k - m); p < B && p <= k + m; ++p)
                            (dp[i][j][k] += dp[i - 1][l][p]) %= mod;
        int ans = 0;
        for (int i = 0; i < B; ++i)
            for (int j = i + 1; j < B; ++j) (ans += dp[n][i][j]) %= mod;
        cout << ans << '\n';
    }
    return 0;
}
