#include <bits/stdc++.h>

using namespace std;

using ll = long long;

template <typename T>
array<T, 3> ext_gcd(T a, T b) {
    T old_r = a, r = b, old_s = 1, s = 0, old_t = 0, t = 1;
    while (r != 0) {
        T quot = old_r / r;
        tie(old_r, r) = make_pair(r, old_r - quot * r);
        tie(old_s, s) = make_pair(s, old_s - quot * s);
        tie(old_t, t) = make_pair(t, old_t - quot * t);
    }
    if (old_r < 0) {
        old_r *= -1;
        old_s *= -1;
        old_t *= -1;
    }
    // gcd, coeff of a, coeff of b
    return {old_r, old_s, old_t};
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        ll k, r1, r2, a1, a2;
        cin >> k >> r1 >> r2 >> a1 >> a2;
        auto [g, c1, c2] = ext_gcd(r1, r2);
        if (a1 % g != a2 % g) {
            cout << 0 << '\n';
        } else {
            // n = a1 + c1 * r1
            // n = a2 + c2 * r2
            // a1 - a2 = (-c1) * r1 + c2 * r2
            // c1' * r1 + c2' * r2 = g
            c2 *= (a1 - a2) / g;
            ll n = a2 + c2 * r2;
            ll l = r1 * (r2 / g);
            ((n %= l) += l) %= l;
            // n = smallest sol now
            // n + r*l <= k
            // r*l <= k - n
            cout << max(k - n + l, 0ll) / l << '\n';
        }
    }
}
