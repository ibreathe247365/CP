#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
using vi = vector<ll>;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    const int maxn = 200000;
    if ((1 << n) + n + 1 > maxn) {
        cout << "Impossible\n";
    } else {
        cout << "11";
        for (int i = 1; i < (1 << n); ++i) cout << '0';
        for (int i = 0; i < n; ++i) cout << '0';
        cout << ' ';
        cout << "10";
        for (int i = 1; i < (1 << n); ++i) cout << '1';
        for (int i = 0; i < n; ++i) cout << '0';
        cout << '\n';
    }
    return 0;
}
