#include <bits/stdc++.h>

using namespace std;

using ll = long long;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    const int N = 100;
    const int M = N * N;
    auto combine = [](int &a, int b) {
        if (a == -1) a = b;
        else a = min(a, b);
    };
    vector<vector<int>> dp(N + 1, vector<int>(M + 1, -1));
    dp[0][0] = 0;
    for (int i = 1; i <= N; ++i)
        for (int j = 1; j <= M; ++j)
            for (int k = 1; k * k <= j && k <= i; ++k)
                if (dp[i - k][j - k * k] != -1)
                    combine(dp[i][j], 1 + dp[i - k][j - k * k]);
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        if (n * n < m) {
            cout << -1 << '\n';
            continue;
        }
        int ans = dp[n][m];
        if (ans == -1) {
            cout << -1 << '\n';
            continue;
        }
        cout << ans << '\n';
        while (dp[n][m] > 0) {
            for (int k = 1; k <= n && k * k <= m; ++k) {
                if (dp[n][m] == dp[n - k][m - k * k] + 1) {
                    cout << k << ' ';
                    n -= k;
                    m -= k * k;
                    break;
                }
            }
        }
        cout << '\n';
    }
}
