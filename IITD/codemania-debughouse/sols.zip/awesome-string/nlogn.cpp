#include <bits/stdc++.h>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    string s;
    cin >> s;
    string even, odd;
    for (int i = 0; i < n; ++i) {
        if (i & 1)
            even += 'Z' - (s[i] - 'A');
        else
            odd += s[i];
    }

    int ans = 0;
    for (auto x : vector<string>{even, odd}) {
        vector<int> stacks(x.size() + 1, 2e9);
        for (auto c : x) *upper_bound(begin(stacks), end(stacks), c) = c;
        for (int i = 0; i <= (int)x.size(); ++i)
            if (stacks[i] == 2e9) {
                ans += (int)x.size() - i;
                break;
            }
    }
    
    cout << ans << '\n';
    return 0;
}
