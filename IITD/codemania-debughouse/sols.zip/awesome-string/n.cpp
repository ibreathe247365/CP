#include <bits/stdc++.h>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    string s;
    cin >> s;
    string even, odd;
    for (int i = 0; i < n; ++i) {
        if (i & 1)
            even += 'Z' - (s[i] - 'A');
        else
            odd += s[i];
    }

    int ans = 0;
    char A = 'A';
    for (auto x : vector<string>{even, odd}) {
        n = x.size();
        vector<vector<int>> dp(27, vector<int>(n + 1));
        for (int i = 1; i <= 26; ++i) {
            char c = A + i - 1;
            int previous = 0;
            for (int j = 1; j <= n; ++j)
                if (x[j - 1] == c) {
                    dp[i][j] = 1 + max(previous, dp[i - 1][j - 1]);
                    previous = dp[i][j];
                }
            for (int j = 1; j <= n; ++j) dp[i][j] = max(dp[i][j], dp[i][j - 1]);
            for (int j = 1; j <= n; ++j) dp[i][j] = max(dp[i][j], dp[i - 1][j]);
        }
        ans += n - dp[26][n];
    }

    cout << ans << '\n';
    return 0;
}
