#include <iostream>
#include <vector>

using namespace std;

using vi = vector<int>;


/*
 * or = o
 * and = a
 * xor = x
 *
 * claim: 4 numbers are enough if an answer exists
 *
 */

int main() {
    cin.tie(nullptr);
    ios_base::sync_with_stdio(false);

    const int B = 63;
    int t;
    cin >> t;
    while (t--) {
        int a, b, c;
        cin >> a >> b >> c;
        vector<vector<vi>> bits(B);
        int possible = 1;
        for (int i = 0; possible && (i < B); ++i) {
            int ai = (a >> i) & 1;
            int bi = (b >> i) & 1;
            int ci = (c >> i) & 1;
            int mask = (ai << 2) | (bi << 1) | ci;
            switch (mask) {
                case 0b000:
                    bits[i] = {vi{0}, vi{0, 0}, vi{0, 0, 0}, vi{0, 0, 0, 0}};
                    break;
                case 0b001:
                    possible = 0;
                    break;
                case 0b010:
                    bits[i] = {vi{0, 1, 1}, vi{0, 0, 1, 1}};
                    break;
                case 0b011:
                    bits[i] = {vi{0, 1}, vi{0, 0, 1}, vi{0, 0, 0, 1}};
                    break;
                case 0b100:
                    possible = 0;
                    break;
                case 0b101:
                    possible = 0;
                    break;
                case 0b110:
                    bits[i] = {vi{1, 1}, vi{1, 1, 1, 1}};
                    break;
                case 0b111:
                    bits[i] = {vi{1}, vi{1, 1, 1}};
                    break;
            }
        }

        int final_size = -1;
        for (int size = 1; possible && (size <= 4); ++size) {
            int cnt = 1;
            for (auto &x : bits) {
                int w = 0;
                for (auto &y : x) w |= (y.size() == size);
                cnt &= w;
                if (!cnt) break;
            }
            if (cnt) {
                final_size = size;
                break;
            }
        }

        if (final_size == -1) {
            cout << -1 << '\n';
        } else {
            vi ans(final_size);
            for (int i = 0; i < B; ++i) {
                vi c;
                for (auto &b : bits[i])
                    if (b.size() == final_size) {
                        c = b;
                        break;
                    }
                for (int j = 0; j < final_size; ++j) ans[j] ^= (c[j] << i);
            }

            cout << ans.size() << '\n';
            for (auto x : ans) cout << x << ' ';
            cout << '\n';
        }
    }

    return 0;
}
