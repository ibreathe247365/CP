#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
using vi = vector<ll>;

int main() {
    cin.tie(nullptr);
    ios_base::sync_with_stdio(false);
    cout.tie(nullptr);
    ll t;
    cin >> t;

    vector<vector<vi>> v = {{vi{0}, vi{0, 0}, vi{0, 0, 0}, vi{0, 0, 0, 0}},
                            {},
                            {vi{0, 1, 1}, vi{0, 0, 1, 1}},
                            {vi{0, 1}, vi{0, 0, 1}, vi{0, 0, 0, 1}},
                            {},
                            {},
                            {vi{1, 1}, vi{1, 1, 1, 1}},
                            {vi{1}, vi{1, 1, 1}}};

    while (t--) {
        ll a, b, c;
        cin >> a >> b >> c;
        vector<vi>* bits[61];
        ll possible = 1;
        for (ll i = 0; i < 61; ++i) {
            ll ai = (a >> i) & 1;
            ll bi = (b >> i) & 1;
            ll ci = (c >> i) & 1;
            ll mask = (ai << 2) | (bi << 1) | ci;
            bits[i] = &v[mask];
            if (!(possible = !(mask == 1 || mask == 4 || mask == 5))) break;
        }

        ll final_size = -1;
        for (ll size = 1; size <= 4; ++size) {
            ll cnt = possible;
            for (auto &x : bits) {
                ll w = 0;
                for (auto &y : *x) w |= (y.size() == size);
                cnt &= w;
                if (!cnt) break;
            }
            if (cnt) {
                final_size = size;
                break;
            }
        }

        if (final_size == -1) {
            cout << -1 << '\n';
        } else {
            vi ans(final_size);
            for (ll i = 0; i < 61; ++i) {
                vi c;
                for (auto &b : *bits[i])
                    if (b.size() == final_size) {
                        c = b;
                        break;
                    }
                for (ll j = 0; j < final_size; ++j) ans[j] ^= (c[j] << i);
            }

            cout << ans.size() << '\n';
            for (auto x : ans) cout << x << ' ';
            cout << '\n';
        }
    }

    return 0;
}
