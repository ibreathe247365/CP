#include <bits/stdc++.h>

using namespace std;

using ll = long long;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        map<int, ll> freq;
        while (n--) {
            int x;
            cin >> x;
            freq[x]++;
        }
        ll ans = 0, coin = -1;
        for (auto &[x, y] : freq) {
            if (ans <= x * y) {
                ans = x * y;
                coin = x;
            }
        }
        cout << coin << ' ' << ans << '\n';
    }
}
