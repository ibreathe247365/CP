#include <bits/stdc++.h>

using namespace std;
using ll = long long;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    ll n, k, c1, c2;
    cin >> n >> k >> c1 >> c2;

    vector<ll> a(n);
    for (auto &x : a) cin >> x;

    ll ans = *max_element(begin(a), end(a));
    ll l = -1e9L, r = ans;

    while (l <= r) {
        ll m = (l + r) / 2;
        ll total = 0;
        for (auto x : a) {
            ll cost = c1 * max(0LL, x - m);
            ll half_cost = 0;
            do {
                half_cost += c2;
                x /= 2;
                cost = min(cost, c1 * max(0LL, x - m) + half_cost);
            } while (x);
            total += cost;
        }

        if (total <= k) {
            ans = m;
            r = m - 1;
        } else {
            l = m + 1;
        }
    }

    cout << ans << '\n';
    return 0;
}
