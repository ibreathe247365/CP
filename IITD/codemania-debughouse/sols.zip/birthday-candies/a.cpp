#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
using vi = vector<ll>;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    ll ans = 0;
    vector<pair<ll, ll>> v(n);
    vector<ll> pre(n + 1), suf(n + 2);
    for (int i = 0; i < n; ++i) {
        ll a, b;
        cin >> a >> b;
        v[i] = {a, max(0ll, a - b)};
        pre[i + 1] = pre[i] + v[i].second;
    }
    for (int i = n; i >= 1; --i) suf[i] = suf[i + 1] + v[i - 1].second;
    for (int i = 0; i < n; ++i)
        ans = max(ans, v[i].first + suf[i + 2] + pre[i]);
    cout << ans << '\n';
    return 0;
}
